import{E as e,O as t,w as n}from"./bridge-CH8mOJsh.js";import{c as r}from"./index-BqiVcfvH.js";import"./filled-button-DvzY9ORb.js";var i=(e,t)=>n(e)||t,a=3600,o=24;function s(){let n=document.createElement(`md-dialog`);n.id=`autokeybox-dialog`,e(`autokeybox_interval`,String(o*a)).then(e=>{let s=String(Math.round(parseInt(e||String(o*a),10)/a)||o);n.innerHTML=`
      <div slot="headline">
        <div class="ap-dialog-headline">
          <md-icon aria-hidden="true">vpn_key</md-icon>
          <span>${i(`autokeybox_title`,`Auto Keybox`)}</span>
        </div>
      </div>
      <div slot="content">
        <p class="ap-dialog-desc">${i(`autokeybox_desc`,`Automatically fetches a new valid keybox at a set interval.`)}</p>

        <div class="list-item">
          <div class="li-icon"><md-icon aria-hidden="true">schedule</md-icon></div>
          <div class="list-item-content">
            <div class="toggle-text">${i(`autokeybox_interval`,`Interval (hours)`)}</div>
            <span class="supporting-text">${i(`autokeybox_interval_desc`,`How often to check for new keyboxes. Default 24 hours (1 day).`)}</span>
          </div>
          <div class="spacer"></div>
          <input type="number" id="ak-interval" class="ap-interval-input" min="1" value="${s}" aria-label="${i(`autokeybox_interval`,`Interval (hours)`)}">
        </div>
      </div>
      <div slot="actions">
        <md-text-button id="ak-cancel">${i(`dialog_cancel`,`Cancel`)}</md-text-button>
        <md-filled-button id="ak-save">${i(`dialog_save`,`Save`)}</md-filled-button>
      </div>
    `,document.body.appendChild(n),n.addEventListener(`close`,()=>document.body.removeChild(n));let c=n.querySelector(`#ak-interval`),l=n.querySelector(`#ak-save`);n.querySelector(`#ak-cancel`).addEventListener(`click`,()=>n.close()),l.addEventListener(`click`,()=>{let e=parseInt(c.value||String(o),10);t(`autokeybox_interval`,String(Math.max(1,e)*a)),r(i(`autokeybox_saved`,`Auto Keybox settings saved`),{icon:`check_circle`,type:`success`,autoCloseDelay:2500}),n.close()}),n.show()})}function c(){let e=document.getElementById(`toggle-background_autokeybox-row`);if(!e)return;let t=e.querySelector(`.list-item-content`);t&&(t.style.cursor=`pointer`,t.addEventListener(`click`,s))}export{c as wireAutokeybox};