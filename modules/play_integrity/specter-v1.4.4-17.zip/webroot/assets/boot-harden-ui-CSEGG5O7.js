import{E as e,O as t,w as n}from"./bridge-CH8mOJsh.js";import{c as r}from"./index-BqiVcfvH.js";var i=(e,t)=>n(e)||t;function a(){let n=document.createElement(`md-dialog`);e(`toggle_boot_hardening`,`1`).then(a=>{let o=a!==`0`;e(`boot_hardening_proc`,`1`).then(a=>{e(`boot_hardening_bootmode`,`1`).then(e=>{let s=o?``:`<div style="display:flex;align-items:center;gap:8px;padding:12px 16px;background:var(--md-sys-color-surface-variant);border-radius:12px;margin:0 0 12px 0;color:var(--md-sys-color-on-surface-variant);font-size:0.875rem;"><md-icon>info</md-icon><span>${i(`feature_disabled_desc`,`Feature is disabled, enable it in Control to configure`)}</span></div>`;n.innerHTML=`
        <div slot="headline">
          <div class="at-dialog-headline">
            <md-icon aria-hidden="true">security</md-icon>
            <span>${i(`boot_harden_dialog_title`,`Boot Hardening`)}</span>
          </div>
        </div>
        <div slot="content">
          <p class="at-dialog-desc">${i(`boot_harden_dialog_desc`,`Choose which hardening measures to apply at boot.`)}</p>
          ${s}
          <div class="list-container at-dialog-list">
            <div class="list-item list-item--toggle">
              <div class="li-icon"><md-icon aria-hidden="true">security</md-icon></div>
              <div class="list-item-content">
                <div class="toggle-text">${i(`boot_harden_proc`,`Proc & File Protection`)}</div>
                <span class="supporting-text">${i(`boot_harden_proc_desc`,`Protect /proc/cmdline, /proc/net/unix, install-recovery.sh`)}</span>
              </div>
              <div class="spacer"></div>
              <md-switch icons id="bh-selinux" ${a===`1`?`selected`:``} ${o?``:`disabled`}></md-switch>
            </div>

            <div class="list-item list-item--toggle">
              <div class="li-icon"><md-icon aria-hidden="true">smartphone</md-icon></div>
              <div class="list-item-content">
                <div class="toggle-text">${i(`boot_harden_bootmode`,`Hide Recovery Bootmode`)}</div>
                <span class="supporting-text">${i(`boot_harden_bootmode_desc`,`Spoof bootmode away from "recovery" to hide recovery status`)}</span>
              </div>
              <div class="spacer"></div>
              <md-switch icons id="bh-bootmode" ${e===`1`?`selected`:``} ${o?``:`disabled`}></md-switch>
            </div>
          </div>
        </div>
        <div slot="actions">
          <md-text-button id="bh-cancel" class="dialog-action-close">${i(`dialog_cancel`,`Cancel`)}</md-text-button>
          <md-filled-button id="bh-save" ${o?``:`disabled`}>${i(`dialog_save`,`Save`)}</md-filled-button>
        </div>
      `,document.body.appendChild(n),n.addEventListener(`close`,()=>document.body.removeChild(n));let c=n.querySelector(`#bh-save`);n.querySelector(`#bh-cancel`).addEventListener(`click`,()=>n.close()),c.addEventListener(`click`,async()=>{c.disabled=!0;try{let e=n.querySelector(`#bh-selinux`),a=n.querySelector(`#bh-bootmode`);t(`boot_hardening_proc`,e.selected?`1`:`0`),t(`boot_hardening_bootmode`,a.selected?`1`:`0`),r(i(`toast_success`,`Done`),{icon:`check_circle`,type:`success`,autoCloseDelay:2500}),n.close()}catch{r(i(`simple_toast_error`,`Failed`),{icon:`error`,type:`error`,autoCloseDelay:3e3})}finally{c.disabled=!1}}),n.show()})})})}function o(){let e=document.getElementById(`toggle-boot_hardening-row`);if(!e)return;let t=e.querySelector(`.list-item-content`);t&&(t.style.cursor=`pointer`,t.addEventListener(`click`,a))}export{o as wireBootHarden};