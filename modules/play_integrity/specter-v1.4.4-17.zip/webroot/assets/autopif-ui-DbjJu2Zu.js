import{E as e,O as t,w as n}from"./bridge-CH8mOJsh.js";import{c as r}from"./index-BqiVcfvH.js";import"./filled-button-DvzY9ORb.js";var i=(e,t)=>n(e)||t,a=3600,o=24;function s(){let n=document.createElement(`md-dialog`);n.id=`autopif-dialog`,e(`autopif_interval`,String(o*a)).then(e=>{let s=String(Math.round(parseInt(e||String(o*a),10)/a)||o);n.innerHTML=`
      <div slot="headline">
        <div class="ap-dialog-headline">
          <md-icon aria-hidden="true">fingerprint</md-icon>
          <span>${i(`autopif_title`,`Auto PIF`)}</span>
        </div>
      </div>
      <div slot="content">
        <p class="ap-dialog-desc">${i(`autopif_desc`,`Automatically fetches new Play Integrity fingerprints at a set interval.`)}</p>

        <div class="list-item">
          <div class="li-icon"><md-icon aria-hidden="true">schedule</md-icon></div>
          <div class="list-item-content">
            <div class="toggle-text">${i(`autopif_interval`,`Interval (hours)`)}</div>
            <span class="supporting-text">${i(`autopif_interval_desc`,`How often to check for new fingerprints. Default 24 hours (1 day).`)}</span>
          </div>
          <div class="spacer"></div>
          <input type="number" id="ap-interval" class="ap-interval-input" min="1" value="${s}" aria-label="${i(`autopif_interval`,`Interval (hours)`)}">
        </div>
      </div>
      <div slot="actions">
        <md-text-button id="ap-cancel">${i(`dialog_cancel`,`Cancel`)}</md-text-button>
        <md-filled-button id="ap-save">${i(`dialog_save`,`Save`)}</md-filled-button>
      </div>
    `,document.body.appendChild(n),n.addEventListener(`close`,()=>document.body.removeChild(n));let c=n.querySelector(`#ap-interval`),l=n.querySelector(`#ap-save`);n.querySelector(`#ap-cancel`).addEventListener(`click`,()=>n.close()),l.addEventListener(`click`,()=>{let e=parseInt(c.value||String(o),10);t(`autopif_interval`,String(Math.max(1,e)*a)),r(i(`autopif_saved`,`Auto PIF settings saved`),{icon:`check_circle`,type:`success`,autoCloseDelay:2500}),n.close()}),n.show()})}function c(){let e=document.getElementById(`toggle-background_autopif-row`);if(!e)return;let t=e.querySelector(`.list-item-content`);t&&(t.style.cursor=`pointer`,t.addEventListener(`click`,s))}export{c as wireAutopif};