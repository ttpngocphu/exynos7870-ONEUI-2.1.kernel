import{E as e,O as t,w as n}from"./bridge-CH8mOJsh.js";import{c as r}from"./index-BqiVcfvH.js";var i=(e,t)=>n(e)||t;function a(){let n=document.createElement(`md-dialog`);e(`toggle_adb_disabler`,`1`).then(a=>{let o=a!==`0`;Promise.all([e(`toggle_adb_disabler_dev_options`,`1`),e(`toggle_adb_disabler_usb_debug`,`1`),e(`toggle_adb_disabler_oem_unlock`,`1`)]).then(([e,a,s])=>{let c=o?``:`<div style="display:flex;align-items:center;gap:8px;padding:12px 16px;background:var(--md-sys-color-surface-variant);border-radius:12px;margin:0 0 12px 0;color:var(--md-sys-color-on-surface-variant);font-size:0.875rem;"><md-icon>info</md-icon><span>${i(`feature_disabled_desc`,`Feature is disabled, enable it in Control to configure`)}</span></div>`;n.innerHTML=`
        <div slot="headline">
          <div class="at-dialog-headline">
            <md-icon aria-hidden="true">usb_off</md-icon>
            <span>${i(`control_toggle_adb_disabler`,`ADB Disabler`)}</span>
          </div>
        </div>
        <div slot="content">
          <p class="at-dialog-desc">${i(`adb_disabler_dialog_desc`,`Choose which developer settings to disable at boot.`)}</p>
          ${c}
          <div class="list-container at-dialog-list">
            <div class="list-item list-item--toggle">
              <div class="li-icon"><md-icon aria-hidden="true">developer_mode</md-icon></div>
              <div class="list-item-content">
                <div class="toggle-text">${i(`adb_disabler_dev_options`,`Disable Developer Options`)}</div>
                <span class="supporting-text">${i(`adb_disabler_dev_options_desc`,`Disables developer options toggle in Settings`)}</span>
              </div>
              <div class="spacer"></div>
              <md-switch icons id="adb-dev-options" ${e===`1`?`selected`:``} ${o?``:`disabled`}></md-switch>
            </div>

            <div class="list-item list-item--toggle">
              <div class="li-icon"><md-icon aria-hidden="true">adb</md-icon></div>
              <div class="list-item-content">
                <div class="toggle-text">${i(`adb_disabler_usb_debug`,`Disable USB Debugging`)}</div>
                <span class="supporting-text">${i(`adb_disabler_usb_debug_desc`,`Disables ADB, strips adb from USB config, locks OEM unlock`)}</span>
              </div>
              <div class="spacer"></div>
              <md-switch icons id="adb-usb-debug" ${a===`1`?`selected`:``} ${o?``:`disabled`}></md-switch>
            </div>

            <div class="list-item list-item--toggle">
              <div class="li-icon"><md-icon aria-hidden="true">lock_outline</md-icon></div>
              <div class="list-item-content">
                <div class="toggle-text">${i(`adb_disabler_oem_unlock`,`Hide OEM Unlock Support`)}</div>
                <span class="supporting-text">${i(`adb_disabler_oem_unlock_desc`,`Hides OEM unlock toggle from developer options`)}</span>
              </div>
              <div class="spacer"></div>
              <md-switch icons id="adb-oem-unlock" ${s===`1`?`selected`:``} ${o?``:`disabled`}></md-switch>
            </div>
          </div>
        </div>
        <div slot="actions">
          <md-text-button id="adb-cancel" class="dialog-action-close">${i(`dialog_cancel`,`Cancel`)}</md-text-button>
          <md-filled-button id="adb-save" ${o?``:`disabled`}>${i(`dialog_save`,`Save`)}</md-filled-button>
        </div>
      `,document.body.appendChild(n),n.addEventListener(`close`,()=>document.body.removeChild(n));let l=n.querySelector(`#adb-dev-options`),u=n.querySelector(`#adb-usb-debug`),d=n.querySelector(`#adb-oem-unlock`),f=n.querySelector(`#adb-save`);n.querySelector(`#adb-cancel`).addEventListener(`click`,()=>n.close()),f.addEventListener(`click`,async()=>{f.disabled=!0;try{t(`toggle_adb_disabler_dev_options`,l.selected?`1`:`0`),t(`toggle_adb_disabler_usb_debug`,u.selected?`1`:`0`),t(`toggle_adb_disabler_oem_unlock`,d.selected?`1`:`0`),r(i(`toast_success`,`Done`),{icon:`check_circle`,type:`success`,autoCloseDelay:2500}),n.close()}catch{r(i(`simple_toast_error`,`Failed`),{icon:`error`,type:`error`,autoCloseDelay:3e3})}finally{f.disabled=!1}}),n.show()})})}function o(){let e=document.getElementById(`toggle-adb_disabler-row`);if(!e)return;let t=e.querySelector(`.list-item-content`);t&&(t.style.cursor=`pointer`,t.addEventListener(`click`,a))}export{o as wireAdbDisabler};