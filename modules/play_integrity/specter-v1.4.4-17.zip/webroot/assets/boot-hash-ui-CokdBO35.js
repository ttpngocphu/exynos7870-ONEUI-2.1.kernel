import{S as e,n as t,r as n,t as r,w as i}from"./bridge-CH8mOJsh.js";import{c as a}from"./index-BqiVcfvH.js";var o=(e,t)=>i(e)||t;function s(){let e=t();return e?e+`/config`:``}function c(){let t=document.getElementById(`boot-hash-btn`);t&&t.addEventListener(`click`,async()=>{let t=n(),i=s();if(!t||!i)return;let c=e(i+`/custom_boot_hash.val`),l=((await r(`cat ${c} 2>/dev/null || echo ""`)).stdout||``).trim(),u=document.createElement(`md-dialog`);u.innerHTML=`
      <div slot="headline">${o(`boot_hash_dialog_title`,`Custom Boot Hash`)}</div>
      <div slot="content" style="min-height:0">
        <md-outlined-text-field id="boot-hash-input" type="text" label="${o(`boot_hash_label`,`Boot Hash (SHA256)`)}" placeholder="${o(`boot_hash_placeholder`,`64 hex characters`)}" maxlength="64" autocapitalize="none" style="width:100%;margin-top:8px;--md-outlined-text-field-container-shape:14px;font-family:monospace;--md-outlined-field-with-trailing-content-trailing-space:24px;overflow:hidden">
          <div slot="trailing-icon" style="display:flex;align-items:center;gap:2px">
            <md-icon-button id="boot-hash-paste" style="--md-icon-button-icon-size:18px;width:32px;height:32px" aria-label="${o(`kb_paste_aria`,`Paste from clipboard`)}">
              <md-icon>content_paste</md-icon>
            </md-icon-button>
            <md-icon-button id="boot-hash-zero" style="--md-icon-button-icon-size:18px;width:32px;height:32px" aria-label="${o(`boot_hash_zero_aria`,`Set hash to zeros`)}">
              <md-icon>restart_alt</md-icon>
            </md-icon-button>
          </div>
        </md-outlined-text-field>
        <p class="md-typescale-body-small" style="margin:12px 0 4px;opacity:.7">
          ${o(`boot_hash_info`,`Leave empty to use auto-computed boot hash. The hash is a 64-character hex string.`)}
        </p>
      </div>
      <div slot="actions">
        <md-text-button id="boot-hash-clear">${o(`dialog_clear`,`Clear`)}</md-text-button>
        <md-text-button id="boot-hash-cancel">${o(`dialog_cancel`,`Cancel`)}</md-text-button>
        <md-filled-tonal-button id="boot-hash-save">${o(`dialog_save`,`Save`)}</md-filled-tonal-button>
      </div>
    `,document.body.appendChild(u);let d=u.querySelector(`#boot-hash-input`);d&&l&&(d.value=l);let f=u.querySelector(`#boot-hash-paste`);f==null||f.addEventListener(`click`,async()=>{try{let e=await navigator.clipboard.readText();e&&d&&(d.value=e)}catch{}});let p=u.querySelector(`#boot-hash-zero`);p==null||p.addEventListener(`click`,()=>{d&&(d.value=`0`.repeat(64))}),u.querySelector(`#boot-hash-cancel`).addEventListener(`click`,()=>u.close()),u.querySelector(`#boot-hash-clear`).addEventListener(`click`,async()=>{try{await r(`rm -f ${c}`),await r(`sh ${e(t+`/refresh_desc.sh`)}`),a(o(`boot_hash_cleared`,`Custom boot hash cleared`),{icon:`check_circle`,type:`success`,autoCloseDelay:2500}),u.close()}catch{a(o(`simple_toast_error`,`Failed`),{icon:`error`,type:`error`,autoCloseDelay:3e3})}}),u.querySelector(`#boot-hash-save`).addEventListener(`click`,async()=>{let n=d.value.trim();if(n&&!/^[a-f0-9]{64}$/.test(n)){a(o(`boot_hash_invalid`,`Invalid hash (must be 64 hex characters)`),{icon:`error`,type:`error`,autoCloseDelay:3e3});return}try{n?(await r(`mkdir -p ${e(i)} && printf '%s' ${e(n)} > ${c}`),await r(`su -c "resetprop -n ro.boot.vbmeta.digest ${e(n)}" 2>/dev/null || true`)):await r(`rm -f ${c}`),await r(`sh ${e(t+`/refresh_desc.sh`)}`),a(o(`boot_hash_saved`,`Custom boot hash saved`),{icon:`check_circle`,type:`success`,autoCloseDelay:2500}),u.close()}catch{a(o(`boot_hash_save_error`,`Failed to save`),{icon:`error`,type:`error`,autoCloseDelay:4e3})}}),u.addEventListener(`close`,()=>document.body.removeChild(u)),u.show()})}export{c as wireBootHash};