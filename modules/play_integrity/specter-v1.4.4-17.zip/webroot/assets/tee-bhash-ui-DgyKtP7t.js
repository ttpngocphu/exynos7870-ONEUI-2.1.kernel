import{o as e,w as t}from"./bridge-CH8mOJsh.js";import{c as n,n as r,s as i}from"./index-BqiVcfvH.js";var a=(e,n)=>t(e)||n;function o(){let t=document.getElementById(`tee-hash-btn`);t&&t.addEventListener(`click`,()=>{let t=document.getElementById(`progress-dialog`),o=document.getElementById(`progress-label`);o&&(o.textContent=a(`check_tee_hash`,`TEE & Boot Hash`)),t==null||t.show();let c=[],l=e(`check_tee_bhash.sh`,`common`);l.stdout.on(`data`,e=>{i(e),c.push(e)}),l.on(`exit`,e=>{t==null||t.close();let i=c.filter(e=>e.includes(`=`));if(e!==0&&!i.length){n(a(`simple_toast_error`,`Failed`),{icon:`error`,type:`error`,autoCloseDelay:3e3}),r(`check_tee_bhash.sh`,c.join(`
`),e);return}let o={};for(let e of i){let t=e.match(/^(\w+)=(.+)$/);t&&(o[t[1]]=t[2].trim())}s(o.tee_status||`unknown`,o.tee_bhash||``,o.boot_hash||``,o.vbmeta_hash||``,o.tee_tier||``),r(`check_tee_bhash.sh`,c.join(`
`),e)}),l.on(`error`,()=>{t==null||t.close(),n(a(`simple_toast_error`,`Failed`),{icon:`error`,type:`error`,autoCloseDelay:3e3})})})}function s(e,t,r,i,o){let s=e===`normal`?`check_circle`:e===`broken`?`error`:`help`,c=`tee-status--${e===`normal`?`normal`:e===`broken`?`broken`:`unknown`}`,l=e===`normal`?a(`tee_status_normal`,`Normal`):e===`broken`?a(`tee_status_broken`,`Broken`):e===`error`?a(`tee_status_error`,`Error`):a(`tee_status_unknown`,`Unknown`),u=o===`2`?`verified`:o===`1`?`security`:`shield`,d=o===`2`?a(`tee_tier_strongbox`,`StrongBox`):o===`1`?a(`tee_tier_tee`,`TEE`):o===`0`?a(`tee_tier_software`,`Software`):a(`tee_tier_unknown`,`Unknown`),f=i&&t&&i!==t,p=f?`boot-hash-text boot-hash-text--mismatch`:`boot-hash-text`,m=f?`boot-hash-text boot-hash-text--mismatch`:`boot-hash-text`;function h(e,t,n,r){return t?`<div class="tee-hash-row">
      <span class="tee-hash-label">${e}</span>
      <span class="tee-hash-value">
        <code class="${r}">${t}</code>
        <md-icon-button id="${n}" aria-label="${a(`history_copy`,`Copy`)}">
          <md-icon aria-hidden="true">content_copy</md-icon>
        </md-icon-button>
      </span>
    </div>`:``}let g=`<div class="tee-hash-row">
      <span class="tee-hash-label">${a(`tee_status_label`,`TEE Status`)}</span>
      <span class="tee-hash-value">
        <span class="tee-status-badge ${c}"><md-icon aria-hidden="true">${s}</md-icon> ${l}</span>
      </span>
    </div>
    <div class="tee-hash-row">
      <span class="tee-hash-label">${a(`tee_tier_label`,`Security Tier`)}</span>
      <span class="tee-hash-value">
        <span class="tee-tier-badge"><md-icon aria-hidden="true">${u}</md-icon> ${d}</span>
      </span>
    </div>
    <md-divider class="settings-divider"></md-divider>
    ${h(a(`boot_hash_tee`,`Boot Hash (TEE)`),t,`tee-hash-copy-tee`,p)}
    ${h(a(`boot_hash_prop`,`Boot Hash (Prop)`),r,`tee-hash-copy-prop`,`boot-hash-text`)}
    ${h(a(`boot_hash_calc`,`Boot Hash (Calc)`),i,`tee-hash-copy-calc`,m)}`,_=document.createElement(`md-dialog`);_.innerHTML=`<div slot="headline">${a(`check_tee_hash`,`TEE & Boot Hash`)}</div>
    <div slot="content">${g}</div>
    <div slot="actions"><md-text-button id="tee-hash-close">${a(`dialog_close`,`Close`)}</md-text-button></div>`,document.body.appendChild(_),_.querySelector(`#tee-hash-close`).addEventListener(`click`,()=>_.close());let v={"tee-hash-copy-tee":t,"tee-hash-copy-prop":r,"tee-hash-copy-calc":i};for(let[e,t]of Object.entries(v)){var y;(y=_.querySelector(`#${e}`))==null||y.addEventListener(`click`,()=>{t&&navigator.clipboard.writeText(t).then(()=>n(a(`history_copied`,`Copied!`),{icon:`check_circle`,type:`success`,autoCloseDelay:2e3})).catch(()=>n(a(`history_copy_failed`,`Failed`),{icon:`error`,type:`error`,autoCloseDelay:2e3}))})}_.addEventListener(`close`,()=>document.body.removeChild(_)),_.show()}export{o as wireTeeHash};