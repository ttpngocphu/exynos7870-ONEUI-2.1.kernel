import{E as e,O as t,w as n}from"./bridge-CH8mOJsh.js";import{c as r}from"./index-BqiVcfvH.js";var i=(e,t)=>n(e)||t;function a(){let n=document.createElement(`md-dialog`);e(`toggle_action_gms`,`1`).then(a=>{let o=a!==`0`;e(`action_gms_force_stop`,`1`).then(a=>{e(`action_gms_clear_data`,`1`).then(e=>{let s=o?``:`<div style="display:flex;align-items:center;gap:8px;padding:12px 16px;background:var(--md-sys-color-surface-variant);border-radius:12px;margin:0 0 12px 0;color:var(--md-sys-color-on-surface-variant);font-size:0.875rem;"><md-icon>info</md-icon><span>${i(`feature_disabled_desc`,`Feature is disabled, enable it in Control to configure`)}</span></div>`;n.innerHTML=`
        <div slot="headline">
          <div class="at-dialog-headline">
            <md-icon aria-hidden="true">block</md-icon>
            <span>${i(`gms_dialog_title`,`Kill Play Store`)}</span>
          </div>
        </div>
        <div slot="content">
          <p class="at-dialog-desc">${i(`gms_dialog_desc`,`Choose which GMS cleanup actions to run when triggered.`)}</p>
          ${s}
          <div class="list-container at-dialog-list">
            <div class="list-item list-item--toggle">
              <div class="li-icon"><md-icon aria-hidden="true">stop</md-icon></div>
              <div class="list-item-content">
                <div class="toggle-text">${i(`gms_force_stop`,`Force-stop GMS Processes`)}</div>
                <span class="supporting-text">${i(`gms_force_stop_desc`,`Kill droidguard and force-stop Play Store, GMS, GSF, Chrome, SafetyCore, and related GMS processes`)}</span>
              </div>
              <div class="spacer"></div>
              <md-switch icons id="gms-force-stop" ${a===`1`?`selected`:``} ${o?``:`disabled`}></md-switch>
            </div>

            <div class="list-item list-item--toggle">
              <div class="li-icon"><md-icon aria-hidden="true">delete</md-icon></div>
              <div class="list-item-content">
                <div class="toggle-text">${i(`gms_clear_data`,`Clear Play Store Data`)}</div>
                <span class="supporting-text">${i(`gms_clear_data_desc`,`Run pm clear on Play Store to reset its state`)}</span>
              </div>
              <div class="spacer"></div>
              <md-switch icons id="gms-clear-data" ${e===`1`?`selected`:``} ${o?``:`disabled`}></md-switch>
            </div>
          </div>
        </div>
        <div slot="actions">
          <md-text-button id="gms-cancel" class="dialog-action-close">${i(`dialog_cancel`,`Cancel`)}</md-text-button>
          <md-filled-button id="gms-save" ${o?``:`disabled`}>${i(`dialog_save`,`Save`)}</md-filled-button>
        </div>
      `,document.body.appendChild(n),n.addEventListener(`close`,()=>document.body.removeChild(n));let c=n.querySelector(`#gms-save`);n.querySelector(`#gms-cancel`).addEventListener(`click`,()=>n.close()),c.addEventListener(`click`,async()=>{c.disabled=!0;try{let e=n.querySelector(`#gms-force-stop`),a=n.querySelector(`#gms-clear-data`);t(`action_gms_force_stop`,e.selected?`1`:`0`),t(`action_gms_clear_data`,a.selected?`1`:`0`),r(i(`toast_success`,`Done`),{icon:`check_circle`,type:`success`,autoCloseDelay:2500}),n.close()}catch{r(i(`simple_toast_error`,`Failed`),{icon:`error`,type:`error`,autoCloseDelay:3e3})}finally{c.disabled=!1}}),n.show()})})})}function o(){let e=document.getElementById(`toggle-action_gms-row`);if(!e)return;let t=e.querySelector(`.list-item-content`);t&&(t.style.cursor=`pointer`,t.addEventListener(`click`,a))}export{o as wireGms};