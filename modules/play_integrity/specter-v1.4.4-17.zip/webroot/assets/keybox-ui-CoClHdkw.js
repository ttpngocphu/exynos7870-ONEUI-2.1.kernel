import{O as e,S as t,g as n,h as r,r as i,s as a,t as o,w as s}from"./bridge-CH8mOJsh.js";import{c,o as l,t as u}from"./index-BqiVcfvH.js";async function d(e){let n=(e,t)=>s(e)||t,i=`/sdcard`,a=[],c=null,l=!1,u=document.createElement(`md-dialog`);u.className=`fb-dialog`;function d(e,t,n,i,a){let o=`fb-row`+(i?``:` fb-row--file`)+(a?` fb-row--selected`:``),s=`fb-row-icon`+(i?` fb-row-icon--folder`:` fb-row-icon--file`);return`<div class="${o}" data-path="${r(e)}">
      <span class="${s}">
        <md-icon class="fb-row-icon-inner">${t}</md-icon>
      </span>
      <span class="fb-row-name">${r(n)}</span>
      ${i?`<md-icon class="fb-chevron">chevron_right</md-icon>`:``}
    </div>`}function f(){var t,o,m,h;let g=a.filter(e=>e.isFolder),_=a.filter(e=>!e.isFolder&&(l||e.name.endsWith(`.xml`)||e.name.endsWith(`.bak`)));u.innerHTML=`
      <div slot="headline" class="fb-headline">
        ${i===`/sdcard`?``:`<md-icon-button id="fb-back" class="fb-back-btn"><md-icon>arrow_back</md-icon></md-icon-button>`}
        <span class="fb-path">${r(i)}</span>
      </div>
      <div slot="content" class="fb-content">
        ${i!==`/`&&i!==`/sdcard`?d(`..`,`folder_open`,`..`,!0,!1):``}
        ${g.map(e=>d(e.path,`folder`,e.name,!0,!1)).join(``)}
        ${_.length===0&&g.length===0?`<div class="fb-empty">`+(s(`file_browser_empty`)||`No XML files found`)+`</div>`:``}
        ${_.map(e=>d(e.path,`description`,e.name,!1,c===e.path)).join(``)}
        ${!l&&_.length<a.length?`<div class="fb-show-all"><span id="fb-show-all">`+(s(`file_browser_show_all`)||`Show all files`)+`</span></div>`:``}
      </div>
      <div slot="actions" class="fb-actions">
        <md-text-button id="fb-cancel">${n(`dialog_close`,`Close`)}</md-text-button>
        <div class="spacer"></div>
        <md-filled-button id="fb-select" class="fb-select-btn" ${c?``:`disabled`}>${n(`fb_select`,`Select`)}</md-filled-button>
      </div>
    `,document.body.contains(u)||(document.body.appendChild(u),u.addEventListener(`close`,()=>document.body.removeChild(u))),(t=u.querySelector(`#fb-back`))==null||t.addEventListener(`click`,()=>{let e=i.substring(0,i.lastIndexOf(`/`))||`/`;i=e===`/`||e.startsWith(`/sdcard`)?e:`/sdcard`,p(i)}),(o=u.querySelector(`#fb-show-all`))==null||o.addEventListener(`click`,()=>{l=!0,f()}),u.querySelectorAll(`.fb-row`).forEach(e=>{e.addEventListener(`click`,async()=>{let t=e.dataset.path;if(!t)return;if(t===`..`){i=i.substring(0,i.lastIndexOf(`/`))||`/`,await p(i);return}let n=a.find(e=>e.path===t);n!=null&&n.isFolder?(i=t.startsWith(`/sdcard`)?t:`/sdcard`,await p(i)):(c=t,f())})}),(m=u.querySelector(`#fb-cancel`))==null||m.addEventListener(`click`,()=>u.close()),(h=u.querySelector(`#fb-select`))==null||h.addEventListener(`click`,()=>{c&&(e(c),u.close())}),document.body.contains(u)||u.show()}async function p(e){u.innerHTML=`
      <div slot="headline" class="fb-headline">
        <span class="fb-path">${r(e)}</span>
      </div>
      <div slot="content" class="fb-loading">
        <md-circular-progress indeterminate></md-circular-progress>
      </div>
    `,document.body.contains(u)||(document.body.appendChild(u),u.addEventListener(`close`,()=>document.body.removeChild(u)),u.show());try{a=((await o(`ls -1p ${t(e)} 2>/dev/null | head -200`)).stdout||``).split(`
`).filter(Boolean).map(t=>({name:t.replace(/\/$/,``),isFolder:t.endsWith(`/`)&&t!==`../`,path:e+`/`+t.replace(/\/$/,``)})).filter(e=>e.name!==`.`&&e.name!==`..`),c=null,l=!1,f()}catch(e){console.warn(`Directory listing failed:`,e),a=[],f()}}await p(i)}var f=(e,t)=>s(e)||t;function p(e,t){for(;e.options.length>1;)e.remove(1);for(let n of t){let t=document.createElement(`option`);t.value=n,t.textContent=n,e.appendChild(t)}}var m=new WeakSet;async function h(){let e=a.KEY_CATALOG,r=await n(e,3e5).catch(()=>null);if(r!=null&&r.entries)return r;if(typeof o!=`function`)return null;try{let n=await o(`curl -sfL --connect-timeout 10 ${t(e)}`);return JSON.parse(n.stdout)}catch{return null}}async function g(){let t=document.getElementById(`kb-provider`);if(!t)return;m.has(t)||(m.add(t),t.addEventListener(`change`,()=>{e(`kb_provider`,t.value)}));let n=await h();if(n!=null&&n.entries){let e=[...new Set(n.entries.map(e=>e.source))].sort(),r=t.value;p(t,e),t.value=r}}function _(){let e=document.getElementById(`custom-keybox-btn`);e&&e.addEventListener(`click`,y)}function v(){let n=document.getElementById(`kb-install-btn`),r=document.querySelector(`.keybox-install-card`),a=r==null?void 0:r.querySelector(`.kic-spinner`);n&&n.addEventListener(`click`,async r=>{if(r.stopPropagation(),!n.disabled){n.disabled=!0,a==null||a.classList.remove(`hidden`);try{e(`kb_custom_type`,``),e(`kb_custom_value`,``),await u(`keybox.sh`);let n=i();n&&(await o(`sh ${t(n+`/features/keybox_info.sh`)}`).catch(()=>{}),await o(`sh ${t(n+`/refresh_desc.sh`)}`).catch(()=>{})),await l()}catch(e){console.warn(`Install error:`,e)}finally{n.disabled=!1,a==null||a.classList.add(`hidden`)}}})}async function y(){let n=document.createElement(`md-dialog`);n.innerHTML=`
    <div slot="headline" style="padding:20px 24px 4px">${f(`custom_kb_title`,`Custom Keybox`)}</div>
    <div slot="content" style="padding:4px 24px">
      <md-filled-card style="padding:12px;border-radius:14px;width:100%;box-sizing:border-box;--md-filled-card-container-color:var(--md-sys-color-surface-container-highest)">
        <div class="custom-kb-section">
          <div class="li-icon"><md-icon>upload_file</md-icon></div>
          <p style="margin:6px 0 2px;font-size:0.8125rem">${f(`custom_kb_file`,`Import File`)}</p>
            <p style="margin:0 0 8px;font-size:0.6875rem;color:var(--md-sys-color-on-surface-variant)">
              ${f(`custom_kb_file_desc`,`Select a keybox XML file from your device`)}
            </p>
          <div style="display:flex;align-items:center;gap:8px;width:100%">
            <md-assist-chip id="kb-file-chip" label="${f(`custom_kb_no_file`,`No file selected`)}" style="min-width:0;overflow:hidden;text-overflow:ellipsis;flex:1;height:36px;font-size:0.75rem"></md-assist-chip>
            <span class="kb-browse-wrap">
              <md-filled-tonal-button class="kb-browse-textonly" aria-label="${f(`custom_kb_browse`,`Browse Files`)}">${f(`custom_kb_browse`,`Browse`)}</md-filled-tonal-button>
              <button class="kb-browse-icononly" aria-label="${f(`custom_kb_browse`,`Browse Files`)}"><md-icon>folder_open</md-icon></button>
            </span>
          </div>
        </div>
      </md-filled-card>

      <md-filled-card style="padding:12px;border-radius:14px;width:100%;box-sizing:border-box;margin-top:8px;--md-filled-card-container-color:var(--md-sys-color-surface-container-highest)">
        <div class="custom-kb-section">
          <div class="li-icon"><md-icon>link</md-icon></div>
          <p style="margin:6px 0 2px;font-size:0.8125rem">${f(`custom_kb_url`,`URL or Path`)}</p>
          <p style="margin:0 0 8px;font-size:0.6875rem;color:var(--md-sys-color-on-surface-variant)">
            ${f(`custom_kb_desc`,`Paste a download URL or enter a device path`)}
          </p>
          <md-outlined-text-field id="kb-url-input" style="width:100%;--md-outlined-text-field-container-shape:14px;--md-sys-shape-corner-extra-small:14px;border-radius:14px;height:44px" placeholder="${f(`kb_url_placeholder`,`https://example.com/keybox.xml or /sdcard/keybox.xml`)}">
            <md-icon-button slot="trailing-icon" id="kb-paste-btn" aria-label="${f(`kb_paste_aria`,`Paste from clipboard`)}">
              <md-icon>content_paste</md-icon>
            </md-icon-button>
          </md-outlined-text-field>
        </div>
      </md-filled-card>
    </div>
    <div slot="actions" style="padding:4px 24px 20px">
      <md-text-button id="kb-clear"><md-icon slot="icon">delete</md-icon> ${f(`custom_kb_clear`,`Clear`)}</md-text-button>
      <div class="spacer"></div>
      <md-filled-tonal-button id="kb-apply">${f(`custom_kb_apply`,`Apply`)}</md-filled-tonal-button>
    </div>
  `,document.body.appendChild(n);let r=n.querySelector(`.kb-browse-wrap`),a=n.querySelector(`#kb-url-input`),s=n.querySelector(`#kb-paste-btn`),u=n.querySelector(`#kb-clear`),p=n.querySelector(`#kb-apply`);r.addEventListener(`click`,()=>{d(e=>{a.value=e;let t=n.querySelector(`#kb-file-chip`);t&&(t.label=e.split(`/`).pop()||e)})}),s.addEventListener(`click`,async()=>{try{let e=await navigator.clipboard.readText();e&&(a.value=e)}catch(e){console.warn(`Clipboard read failed:`,e)}}),u.addEventListener(`click`,async()=>{e(`kb_custom_type`,``),e(`kb_custom_value`,``),e(`kb_private`,``),c(f(`custom_kb_cleared`,`Custom keybox cleared`),{icon:`info`,type:`info`,autoCloseDelay:2500}),n.close()}),p.addEventListener(`click`,async()=>{let r=i(),s=a.value.trim();if(!s){c(f(`toast_enter_url`,`Enter a URL or device path`),{icon:`error`,type:`error`,autoCloseDelay:2500});return}await new Promise(e=>{let t=document.createElement(`md-dialog`);t.className=`private-dialog`,t.innerHTML=`
        <div slot="headline">${f(`custom_kb_title`,`Custom Keybox`)}</div>
        <div slot="content">
          <p class="private-dialog-msg">${f(`custom_kb_private_ask`,`Is this a private keybox?`)}</p>
        </div>
        <div slot="actions">
          <md-text-button id="kb-pri-no" value="no">${f(`custom_kb_no`,`No`)}</md-text-button>
          <md-text-button id="kb-pri-yes" value="yes">${f(`custom_kb_yes`,`Yes`)}</md-text-button>
        </div>
      `,document.body.appendChild(t),t.querySelector(`#kb-pri-no`).addEventListener(`click`,()=>{t.close(),e(!1)}),t.querySelector(`#kb-pri-yes`).addEventListener(`click`,()=>{t.close(),e(!0)}),t.addEventListener(`close`,()=>document.body.removeChild(t)),t.show()})?e(`kb_private`,`true`):e(`kb_private`,``),s.startsWith(`http://`)||s.startsWith(`https://`)?e(`kb_custom_type`,`url`):e(`kb_custom_type`,`path`),e(`kb_custom_value`,s),(await o(`sh ${t(r+`/features/keybox.sh`)}`)).code===0?(c(f(`custom_kb_installed`,`Custom keybox installed`),{icon:`check_circle`,type:`success`,autoCloseDelay:3e3}),await o(`sh ${t(r+`/features/keybox_info.sh`)}`).catch(()=>{}),await o(`sh ${t(r+`/refresh_desc.sh`)}`).catch(()=>{}),await l()):c(f(`custom_kb_install_failed`,`Install failed`),{icon:`error`,type:`error`,autoCloseDelay:5e3}),n.close()}),n.addEventListener(`close`,()=>{document.body.removeChild(n)}),n.show()}export{g as populateProviders,_ as wireCustomKeybox,v as wireKeyboxInstallButton};