import{E as e,O as t,w as n}from"./bridge-CH8mOJsh.js";import{c as r}from"./index-BqiVcfvH.js";var i=(e,t)=>n(e)||t;function a(){let n=document.createElement(`md-dialog`);e(`toggle_rom_fingerprint`,`1`).then(a=>{let o=a!==`0`;e(`rom_fingerprint_hexpatch`,`1`).then(a=>{e(`rom_fingerprint_prefix`,`1`).then(e=>{let s=o?``:`<div style="display:flex;align-items:center;gap:8px;padding:12px 16px;background:var(--md-sys-color-surface-variant);border-radius:12px;margin:0 0 12px 0;color:var(--md-sys-color-on-surface-variant);font-size:0.875rem;"><md-icon>info</md-icon><span>${i(`feature_disabled_desc`,`Feature is disabled, enable it in Control to configure`)}</span></div>`;n.innerHTML=`
        <div slot="headline">
          <div class="at-dialog-headline">
            <md-icon aria-hidden="true">fingerprint</md-icon>
            <span>${i(`rom_fingerprint_dialog_title`,`ROM Fingerprint`)}</span>
          </div>
        </div>
        <div slot="content">
          <p class="at-dialog-desc">${i(`rom_fingerprint_dialog_desc`,`Clean traces of custom ROM identity from build properties.`)}</p>
          ${s}
          <div class="list-container at-dialog-list">
            <div class="list-item list-item--toggle">
              <div class="li-icon"><md-icon aria-hidden="true">search</md-icon></div>
              <div class="list-item-content">
                <div class="toggle-text">${i(`rom_fingerprint_hexpatch`,`Delete ROM Prop Traces`)}</div>
                <span class="supporting-text">${i(`rom_fingerprint_hexpatch_desc`,`Delete build props containing known ROM names (Lineage, crDroid, PixelOS, etc.)`)}</span>
              </div>
              <div class="spacer"></div>
              <md-switch icons id="rf-hexpatch" ${a===`1`?`selected`:``} ${o?``:`disabled`}></md-switch>
            </div>

            <div class="list-item list-item--toggle">
              <div class="li-icon"><md-icon aria-hidden="true">format_clear</md-icon></div>
              <div class="list-item-content">
                <div class="toggle-text">${i(`rom_fingerprint_prefix`,`Strip ROM Prefixes`)}</div>
                <span class="supporting-text">${i(`rom_fingerprint_prefix_desc`,`Strip custom ROM prefixes (aosp_, lineage_) from build fingerprint and display id`)}</span>
              </div>
              <div class="spacer"></div>
              <md-switch icons id="rf-prefix" ${e===`1`?`selected`:``} ${o?``:`disabled`}></md-switch>
            </div>
          </div>
        </div>
        <div slot="actions">
          <md-text-button id="rf-cancel" class="dialog-action-close">${i(`dialog_cancel`,`Cancel`)}</md-text-button>
          <md-filled-button id="rf-save" ${o?``:`disabled`}>${i(`dialog_save`,`Save`)}</md-filled-button>
        </div>
      `,document.body.appendChild(n),n.addEventListener(`close`,()=>document.body.removeChild(n));let c=n.querySelector(`#rf-save`);n.querySelector(`#rf-cancel`).addEventListener(`click`,()=>n.close()),c.addEventListener(`click`,async()=>{c.disabled=!0;try{let e=n.querySelector(`#rf-hexpatch`),a=n.querySelector(`#rf-prefix`);t(`rom_fingerprint_hexpatch`,e.selected?`1`:`0`),t(`rom_fingerprint_prefix`,a.selected?`1`:`0`),r(i(`toast_success`,`Done`),{icon:`check_circle`,type:`success`,autoCloseDelay:2500}),n.close()}catch{r(i(`simple_toast_error`,`Failed`),{icon:`error`,type:`error`,autoCloseDelay:3e3})}finally{c.disabled=!1}}),n.show()})})})}function o(){let e=document.getElementById(`toggle-rom_fingerprint-row`);if(!e)return;let t=e.querySelector(`.list-item-content`);t&&(t.style.cursor=`pointer`,t.addEventListener(`click`,a))}export{o as wireRomFingerprint};