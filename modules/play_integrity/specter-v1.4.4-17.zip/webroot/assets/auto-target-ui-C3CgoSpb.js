import{E as e,O as t,w as n}from"./bridge-CH8mOJsh.js";import{c as r}from"./index-BqiVcfvH.js";import"./outlined-segmented-button-BKnfM-yC.js";import"./filled-button-DvzY9ORb.js";var i=(e,t)=>n(e)||t;function a(){let n=document.createElement(`md-dialog`);n.id=`auto-target-dialog`,Promise.all([e(`auto_target_method`,`instant`),e(`auto_target_interval`,`300`)]).then(([e,a])=>{let o=e===`polling`;n.innerHTML=`
      <div slot="headline">
        <div class="at-dialog-headline">
          <md-icon aria-hidden="true">update</md-icon>
          <span>${i(`auto_target_title`,`Auto Targeting`)}</span>
        </div>
      </div>
      <div slot="content">
        <p class="at-dialog-desc">${i(`auto_target_desc`,`Automatically watches for newly installed apps and adds them to Tricky Store target.txt.`)}</p>

        <div class="at-method-section">
          <div class="at-method-label">${i(`auto_target_method`,`Detection Method`)}</div>
          <md-outlined-segmented-button-set>
            <md-outlined-segmented-button value="instant"${e===`instant`?` selected`:``}>
              <md-icon slot="icon">bolt</md-icon>
              ${i(`auto_target_method_instant`,`Instant`)}
            </md-outlined-segmented-button>
            <md-outlined-segmented-button value="polling"${e===`polling`?` selected`:``}>
              <md-icon slot="icon">schedule</md-icon>
              ${i(`auto_target_method_polling`,`Polling`)}
            </md-outlined-segmented-button>
          </md-outlined-segmented-button-set>
          <div class="at-method-help" id="at-help">${o?i(`auto_target_method_polling_help`,`Checks periodically at a set interval`):i(`auto_target_method_instant_help`,`Detects new installs immediately via inotifyd (recommended)`)}</div>
        </div>

        <div class="list-container at-dialog-list${o?``:` at-hidden`}" id="at-interval-row">
          <div class="list-item">
            <div class="li-icon"><md-icon aria-hidden="true">timer</md-icon></div>
            <div class="list-item-content">
              <div class="toggle-text">${i(`auto_target_interval`,`Interval (seconds)`)}</div>
              <span class="supporting-text">${i(`auto_target_interval_desc`,`How often to check for new apps. Minimum 3 seconds.`)}</span>
            </div>
            <div class="spacer"></div>
            <input type="number" id="at-interval" class="at-interval-input" min="3" value="${a}" aria-label="${i(`auto_target_interval_aria`,`Interval in seconds`)}">
          </div>
        </div>
      </div>
      <div slot="actions">
        <md-text-button id="at-cancel">${i(`dialog_cancel`,`Cancel`)}</md-text-button>
        <md-filled-button id="at-save">${i(`dialog_save`,`Save`)}</md-filled-button>
      </div>
    `,document.body.appendChild(n),n.addEventListener(`close`,()=>document.body.removeChild(n));let s=n.querySelector(`#at-help`),c=n.querySelector(`#at-interval-row`),l=n.querySelector(`#at-interval`),u=n.querySelector(`#at-save`),d=n.querySelector(`#at-cancel`),f=e;function p(e){s.textContent=e?i(`auto_target_method_polling_help`,`Checks periodically at a set interval`):i(`auto_target_method_instant_help`,`Detects new installs immediately via inotifyd (recommended)`),c.classList.toggle(`at-hidden`,!e)}n.querySelectorAll(`md-outlined-segmented-button`).forEach(e=>{e.addEventListener(`click`,()=>{f=e.getAttribute(`value`)||`instant`,p(f===`polling`)})}),p(o),d.addEventListener(`click`,()=>n.close()),u.addEventListener(`click`,()=>{let e=parseInt(l.value||`15`,10);t(`auto_target_method`,f),t(`auto_target_interval`,String(Math.max(3,e))),r(i(`auto_target_saved`,`Auto targeting settings saved`),{icon:`check_circle`,type:`success`,autoCloseDelay:2500}),n.close()}),n.show()})}function o(){let e=document.getElementById(`toggle-background_auto_target-row`);if(!e)return;let t=e.querySelector(`.list-item-content`);t&&(t.style.cursor=`pointer`,t.addEventListener(`click`,a))}export{o as wireAutoTarget};