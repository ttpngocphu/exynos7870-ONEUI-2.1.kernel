import{E as e,O as t,w as n}from"./bridge-CH8mOJsh.js";import{c as r}from"./index-BqiVcfvH.js";var i=(e,t)=>n(e)||t;function a(){let n=document.createElement(`md-dialog`);Promise.all([e(`toggle_prop_handler`,`1`),e(`boot_state_props`,`1`),e(`spoof_build_props`,`1`),e(`region_props`,`1`),e(`toggle_boot_hash`,`1`)]).then(([e,a,o,s,c])=>{let l=e!==`0`,u=l?``:`<div style="display:flex;align-items:center;gap:8px;padding:12px 16px;background:var(--md-sys-color-surface-variant);border-radius:12px;margin:0 0 12px 0;color:var(--md-sys-color-on-surface-variant);font-size:0.875rem;"><md-icon>info</md-icon><span>${i(`feature_disabled_desc`,`Feature is disabled, enable it in Control to configure`)}</span></div>`;n.innerHTML=`
      <div slot="headline">
        <div class="at-dialog-headline">
          <md-icon aria-hidden="true">lock</md-icon>
          <span>${i(`prop_handler_dialog_title`,`Boot State Props`)}</span>
        </div>
      </div>
      <div slot="content">
        <p class="at-dialog-desc">${i(`prop_handler_dialog_desc`,`Manage boot-time property spoofing and cleanup.`)}</p>
        ${u}
        <div class="list-container at-dialog-list">
          <div class="list-item list-item--toggle">
            <div class="li-icon"><md-icon aria-hidden="true">lock</md-icon></div>
            <div class="list-item-content">
              <div class="toggle-text">${i(`prop_handler_boot_state`,`Boot State Props`)}</div>
              <span class="supporting-text">${i(`prop_handler_boot_state_desc`,`Lock bootloader state, verifiedboot, flash.locked, build type/tags`)}</span>
            </div>
            <div class="spacer"></div>
            <md-switch icons id="ph-state" ${a===`1`?`selected`:``} ${l?``:`disabled`}></md-switch>
          </div>

          <div class="list-item list-item--toggle">
            <div class="li-icon"><md-icon aria-hidden="true">badge</md-icon></div>
            <div class="list-item-content">
              <div class="toggle-text">${i(`prop_handler_spoof_build`,`Spoof Build Props`)}</div>
              <span class="supporting-text">${i(`prop_handler_spoof_build_desc`,`Spoof ro.build.flavor to remove userdebug/eng traces`)}</span>
            </div>
            <div class="spacer"></div>
            <md-switch icons id="ph-spoof" ${o===`1`?`selected`:``} ${l?``:`disabled`}></md-switch>
          </div>

          <div class="list-item list-item--toggle">
            <div class="li-icon"><md-icon aria-hidden="true">language</md-icon></div>
            <div class="list-item-content">
              <div class="toggle-text">${i(`prop_handler_region`,`Region Props`)}</div>
              <span class="supporting-text">${i(`prop_handler_region_desc`,`Apply region-specific persist props (IMS, VoLTE, locale)`)}</span>
            </div>
            <div class="spacer"></div>
            <md-switch icons id="ph-region" ${s===`1`?`selected`:``} ${l?``:`disabled`}></md-switch>
          </div>

          <div class="list-item list-item--toggle">
            <div class="li-icon"><md-icon aria-hidden="true">verified_user</md-icon></div>
            <div class="list-item-content">
              <div class="toggle-text">${i(`prop_handler_boot_hash`,`TEE Boot Hash`)}</div>
              <span class="supporting-text">${i(`prop_handler_boot_hash_desc`,`Resolve boot hash from TEE attestation or vbmeta partition at boot`)}</span>
            </div>
            <div class="spacer"></div>
            <md-switch icons id="ph-boot-hash" ${c===`1`?`selected`:``} ${l?``:`disabled`}></md-switch>
          </div>
        </div>
      </div>
      <div slot="actions">
        <md-text-button id="ph-cancel" class="dialog-action-close">${i(`dialog_cancel`,`Cancel`)}</md-text-button>
        <md-filled-button id="ph-save" ${l?``:`disabled`}>${i(`dialog_save`,`Save`)}</md-filled-button>
      </div>
    `,document.body.appendChild(n),n.addEventListener(`close`,()=>document.body.removeChild(n));let d=n.querySelector(`#ph-save`);n.querySelector(`#ph-cancel`).addEventListener(`click`,()=>n.close()),d.addEventListener(`click`,async()=>{d.disabled=!0;try{let e=n.querySelector(`#ph-state`),a=n.querySelector(`#ph-spoof`),o=n.querySelector(`#ph-region`),s=n.querySelector(`#ph-boot-hash`);t(`boot_state_props`,e.selected?`1`:`0`),t(`spoof_build_props`,a.selected?`1`:`0`),t(`region_props`,o.selected?`1`:`0`),t(`toggle_boot_hash`,s.selected?`1`:`0`),r(i(`toast_success`,`Done`),{icon:`check_circle`,type:`success`,autoCloseDelay:2500}),n.close()}catch{r(i(`simple_toast_error`,`Failed`),{icon:`error`,type:`error`,autoCloseDelay:3e3})}finally{d.disabled=!1}}),n.show()})}function o(){let e=document.getElementById(`toggle-prop_handler-row`);if(!e)return;let t=e.querySelector(`.list-item-content`);t&&(t.style.cursor=`pointer`,t.addEventListener(`click`,a))}export{o as wirePropHandler};