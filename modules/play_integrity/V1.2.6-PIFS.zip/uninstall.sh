rm -rf /data/adb/tricky_store/AllTargetMagiskhide.sh
rm -rf /data/adb/tricky_store/denylist.txt
rm -rf /data/adb/tricky_store/target.txt
rm -rf /data/adb/tricky_store/security_patch.txt