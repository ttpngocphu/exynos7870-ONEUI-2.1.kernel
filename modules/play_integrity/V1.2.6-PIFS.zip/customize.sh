# tryigitx

find_busybox() {
  [ -n "$BUSYBOX" ] && return 0
  for path in /data/adb/modules/busybox-ndk/system/*/busybox /data/adb/magisk/busybox /data/adb/ksu/bin/busybox /data/adb/ap/bin/busybox; do
    if [ -x "$path" ]; then
      BUSYBOX="$path"
      return 0
    fi
  done
  return 1
}

if ! find_busybox; then
  ui_print " "
  ui_print "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  ui_print "!               INSTALLATION FAILED                    !"
  ui_print "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  ui_print "! BusyBox not found. This script requires Magisk or"
  ui_print "! KernelSU to be installed correctly."
  ui_print "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  abort "! BusyBox binary is missing."
fi

API=$(getprop ro.build.version.sdk)
PIF_MODULE_DIR="/data/adb/modules/playintegrityfix"
PIF_PROP_PATH="$PIF_MODULE_DIR/module.prop"

if [ "$API" -lt 33 ]; then
  if [ -f "$PIF_PROP_PATH" ]; then
    if ! $BUSYBOX grep -q 'author=osm0sis' "$PIF_PROP_PATH"; then
      ui_print " "
      ui_print "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
      ui_print "!               INSTALLATION FAILED                    !"
      ui_print "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
      ui_print "! Your device is on Android < 13 and you are using an"
      ui_print "! unsupported Play Integrity Fix module."
      ui_print "!"
      ui_print "! You MUST use the 'osm0sis' fork for compatibility."
      ui_print "! Opening the download page for you now..."
      ui_print "!"
      ui_print "! Please uninstall your current Play Integrity Fix module"
      ui_print "! and install the required version from the page that opens."
      ui_print "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
      nohup am start -a android.intent.action.VIEW -d "https://github.com/osm0sis/PlayIntegrityFork" >/dev/null 2>&1 &
      abort "! Required module 'Play Integrity Fork by osm0sis' not found."
    fi
  fi
elif [ -d "$PIF_MODULE_DIR" ]; then
  ui_print " "
  ui_print "⚠️ WARNING: Play Integrity Fix module is detected."
  ui_print "   This module is not needed on Android 13+ and may"
  ui_print "   cause conflicts. Please consider removing it."
  ui_print " "
fi

FILE_PATH="/data/adb/modules/tricky_store/module.prop"
if [ -f "$FILE_PATH" ]; then
    VERSION_CODE=$($BUSYBOX grep -o 'versionCode=[0-9]*' "$FILE_PATH" | $BUSYBOX cut -d'=' -f2)
    if [ "$VERSION_CODE" -lt 107 ]; then
        ui_print " "
        ui_print "⚠️ TrickyStore version is old"
        ui_print " "
    fi
fi

if ! [ -d "/data/adb/modules/tricky_store" ] && ! [ -d "/data/adb/modules_update/tricky_store" ]; then
    ui_print " "
    ui_print " Recommended to install TrickyStore module"
    ui_print " "
fi

backup_file() {
  local file=$1
  if [ -f "$file" ]; then
    mv "$file" "${file}.bak"
    ui_print "- Backed up existing $file to ${file}.bak"
  fi
}

mkdir -p /data/adb/tricky_store
mv "$MODPATH/AllAppsTarget.sh" "/data/adb/tricky_store/AllAppsTarget.sh"
sleep 1

chmod +x "/data/adb/tricky_store/AllAppsTarget.sh"
/data/adb/tricky_store/AllAppsTarget.sh
rm -f "$MODPATH/AllAppsTarget.sh"

KEYBOX_TARGET_PATH="/data/adb/tricky_store/keybox.xml"
KEYBOX_DOWNLOAD_URL="https://tryigit.dev/keybox/download.php?id=random_strong"
MASTER_SECRET="pLpHY1=h{=!uM,Fb!doE9UZ@sqS%Mf"

ui_print " "
ui_print "- Processing keybox.xml..."
backup_file "$KEYBOX_TARGET_PATH"

ui_print "- Attempting to download a new random keybox from server..."
TIMESTAMP=$($BUSYBOX date +%s)
TOKEN_STRING="${TIMESTAMP}${MASTER_SECRET}"
AUTH_TOKEN=$($BUSYBOX echo -n "$TOKEN_STRING" | $BUSYBOX sha256sum | $BUSYBOX awk '{print $1}')

$BUSYBOX wget -q \
  --user-agent="KeyboxHubMagiskModule/1.0" \
  --header="X-Request-Timestamp: $TIMESTAMP" \
  --header="X-Auth-Token: $AUTH_TOKEN" \
  -O "$KEYBOX_TARGET_PATH" "$KEYBOX_DOWNLOAD_URL"
EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]; then
  ui_print "- New keybox.xml downloaded successfully."
else
  ui_print "⚠️ Failed to download new keybox.xml."
  if [ $EXIT_CODE -eq 4 ]; then
    ui_print "   Please check your internet connection (Network Failure)."
  elif [ $EXIT_CODE -eq 8 ]; then
    ui_print "   Server returned an error. Access denied or rate limit exceeded."
  else
    ui_print "   An unexpected error occurred (Error Code: $EXIT_CODE)."
  fi

  if [ -f "${KEYBOX_TARGET_PATH}.bak" ]; then
    mv "${KEYBOX_TARGET_PATH}.bak" "$KEYBOX_TARGET_PATH"
    ui_print "- Restored backup keybox.xml."
  else
    ui_print "⚠️ No backup keybox.xml found to restore."
  fi
fi

$BUSYBOX killall com.google.android.gms
$BUSYBOX killall com.google.android.gms.unstable
$BUSYBOX killall com.android.vending

$BUSYBOX find /data/adb/ -type f \
  ! \( -path "$exclude_path1" -o -path "$exclude_path2" -o -path "$exclude_path3" -o -path "$exclude_path4" \
  -o -path "$exclude_path1/*" -o -path "$exclude_path2/*" -o -path "$exclude_path3/*" -o -path "$exclude_path4/*" \) \
  \( -name "*32*" -o -name "*v7a*" \) -print0 | while IFS= read -r -d '' file; do
    rm -f "$file"
done

if [ -d "/data/adb/modules/zygisk_lsposed" ] || [ -d "/data/adb/modules/zygisk_shamiko" ]; then
    resetprop -d persist.log.tag.LSPosed
    resetprop -d persist.log.tag.LSPosed-Bridge
fi

current_patch_str=$(getprop ro.build.version.security_patch)
if [ -n "$current_patch_str" ]; then
    patch_timestamp=$($BUSYBOX date -d "$current_patch_str" +%s)
    current_timestamp=$($BUSYBOX date +%s)
    seconds_in_6_months=15552000
    six_months_ago_timestamp=$((current_timestamp - seconds_in_6_months))

    if [ "$patch_timestamp" -lt "$six_months_ago_timestamp" ]; then
        sp="/data/adb/tricky_store/security_patch.txt"
        current_year=$($BUSYBOX date +%Y)
        current_month_num=$((10#$($BUSYBOX date +%m)))

        if [ "$current_month_num" -eq 1 ]; then
            prev_month=12
            prev_year=$((current_year - 1))
        else
            prev_month=$((current_month_num - 1))
            prev_year=$current_year
        fi

        formatted_month=$($BUSYBOX printf "%02d" $prev_month)
        echo "${prev_year}${formatted_month}05" > "$sp"
        ui_print " "
        ui_print "- Security patch date spoofed to a recent value."
    fi
fi

ui_print " "
ui_print "  Telegram: t.me/cleverestech"
ui_print " "
ui_print "⚠️ Please read on github LeakedKeyboxs/README.md"
ui_print " "
